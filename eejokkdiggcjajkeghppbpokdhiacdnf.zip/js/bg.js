
chrome.runtime.setUninstallURL("https://sites.google.com/view/popular-browser-wallpaper");

chrome.runtime.onInstalled.addListener(function (object) {
	 if (!localStorage.getItem("enable_note")) {
        localStorage.setItem("enable_note", "yes")
    }
	
	if(object.reason == "install"){
		 var pageurl = 'https://coolthemestores.com/?utm_campaign=si_extensions&utm_medium=newinstall&utm_source=si_granny';
		 chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
			if(tabs.length > 0){
				var tabid = tabs[0].id;
				chrome.tabs.update(tabid, {url: pageurl});
			}
		});
       
    }
	
  
});

// Opens new tab when clicked on extension icon 
chrome.browserAction.onClicked.addListener(function(activeTab) {
    var newURL = "chrome://newtab";
    chrome.tabs.create({ url: newURL });
});

chrome.runtime.onMessage.addListener(
  function(request) {
    if (request.do == "uninstall"){
    	chrome.management.uninstallSelf({"showConfirmDialog":true});
    }
}); 

chrome.runtime.onMessage.addListener(function(t, a, o) {
  if (t.topSites) {
      chrome.topSites.get(function(e) {
          o(e);
      });
      return true;
  }
});

