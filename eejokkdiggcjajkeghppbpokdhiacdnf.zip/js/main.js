$(window).on('load', function(){
	


	toastr.options = {
	  "closeButton": false,
	  "debug": false,
	  "newestOnTop": false,
	  "progressBar": true,
	  "positionClass": "toast-top-right",
	  "preventDuplicates": false,
	  "showDuration": "300",
	  "hideDuration": "500",
	  "timeOut": "2000",
	  "extendedTimeOut": "1500",
	  "showEasing": "swing",
	  "hideEasing": "linear",
	  "showMethod": "fadeIn",
	  "hideMethod": "fadeOut"
	};	
	
	

	
	

	$("#settings-button").trigger('click');
	
	var widgets = ["links","logo","weather"];
	$.each(widgets , function(index, val) {
		if($.cookie(val + 'status') === undefined)
		{
			$.cookie(val + 'status', "true", { expires: 365 });
		}		
		
		if($.cookie(val + 'status') === "true")
		{
			$("#" + val + "-container").addClass('widget-visible');
			$(".widgetoption-" + val).attr("checked","checked");
		}
	});
	
	
	var currentbg = $.cookie('currentbg');
	var randombg = $.cookie('randombg');
	if(randombg === undefined)
	{
		$.cookie('randombg', 'true', { expires: 365 });
		$("#randomizebutton").attr("checked","checked");
	}
	else if(randombg === "true")
	{
		$("#randomizebutton").attr("checked","checked");
	}
	else if(randombg === "false")
	{
		$("#randomizebutton").attr("checked",false);
	}
		
	var $menustatus = $.cookie('menustatus');
	var $url = "";
	
	if(randombg === "false")
	{
		if(currentbg)
		{
            $url = $("li[data-id='" + currentbg +"']").children('img').attr('src');
			//$url = '/bg/' + currentbg + '.jpg';

			$("#background").css('background-image','url('+$url+')');
			$.cookie('currentbg', currentbg, { expires: 7 });
		}
		else
		{
			//$url = '/bg/1.jpg';
            $url = $("li[data-id='1']").children('img').attr('src');

			$("#background").css('background-image','url('+$url+')');
			$.cookie('currentbg', '1', { expires: 7 });
		}		
	}
	else
	{
		var numberimages = $("#bg-images").data('number');
		var randomimage = getRandomInt(1,numberimages);
		//$url = '/bg/' + randomimage + '.jpg';
        $url = $("li[data-id='" + randomimage +"']").children('img').attr('src');
		$("#background").css('background-image','url('+$url+')');
	}

	
	
	//alert($menustatus);
	if($menustatus)
	{
		if($menustatus == 'closed')
		{
				//alert('ok');
				$(".toggler").trigger('click');
		}
		
	}
	else
	{
		$.cookie('menustatus', 'closed', { expires: 7 });				
	}
		
});

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

$(document).on('click', function (e) {
    var
        $popover,
        $target = $(e.target);

    //do nothing if there was a click on popover content
    if ($target.hasClass('popover') || $target.closest('.popover').length) {
        return;
    }

    $('[data-toggle="popover"]').each(function () {
        $popover = $(this);

        if (!$popover.is(e.target) &&
            $popover.has(e.target).length === 0 &&
            $('.popover').has(e.target).length === 0)
        {
            $popover.popover('hide');
			if($.cookie('randombg') === "true")
			{
				$("#randomizebutton").attr("checked","checked");
			}
			else
			{
				$("#randomizebutton").attr("checked",false);	
			}			
			
			
        } else {
            //fixes issue described above
            //$popover.popover('toggle');
        }
    });
});

$(document).on('click','#settings-button',function(e) {
	console.log('ok');
	var widgets = ["links","logo","weather"];
	$.each(widgets , function(index, val) { 
		if($.cookie(val + 'status') == "true")
		{
			$(".widgetoption-" + val).attr("checked","checked");
		}
		else
		{
			$(".widgetoption-" + val).attr("checked",false);
		}
		
	});
	if($.cookie('randombg') === "true")
	{
		$("#randomizebutton").attr("checked","checked");
		
	}
	else
	{
		$("#randomizebutton").attr("checked",false);
	}
	
	
    $("[data-toggle=popover]").popover({
        html : true,
		sanitize: false,
        content: function() {
          var content = $(this).attr("data-popover-content");
          return $("#settings-container").children(".popover-body").html();
        },
        title: function() {
          var title = $(this).attr("data-popover-content");
          return $("#settings-container").children(".popover-heading").html();
        }
    });
});


$(document).on('click','.widgetoption',function(e) {

    var widgetid = $(this).data('widget');
	if($(this).is(':checked'))
	{
		var widgetstatus = true;
		$("#" + widgetid + "-container").addClass('widget-visible');
	}
	else
	{
		var widgetstatus = false;
		$("#" + widgetid + "-container").removeClass('widget-visible');
	}	
	$.cookie(widgetid + 'status', widgetstatus, { expires: 365 });
	toastr.success('Widget settings updated');

});

$(document).on('click','#randomizebutton',function(e) {

	if($(this).is(':checked'))
	{
		$.cookie('randombg', 'true', { expires: 365 });
		toastr.success('Background settings updated');
	}
	else
	{
		$.cookie('randombg', 'false', { expires: 365 });
		toastr.success('Background settings updated');
	}
});


$(document).on('click','.bg',function(e) {

    var $iid = $(this).data('id');
	var $url = $(this).children('img').attr("src");//'/bg/' + $iid + '.jpg';
	
	$("#background").css('background-image','url('+$url+')');
	$.cookie('currentbg', $iid, { expires: 365 });
	toastr.success('Background settings updated');
	
	if($.cookie('randombg') === "true")
	{
		$.cookie('randombg', "false", { expires: 365 });
		$("#randomizebutton").attr("checked",false);
		toastr.info('Random background disabled!');		
	}

});

$(document).ready(function(e) {
	
	
	
	
$( "#searchform" ).submit(function( event ) {

	var searchterm = $('#q').val();
	window.open('https://www.google.com/search?q='+searchterm,'_blank');	
	event.preventDefault();
});
	
	
	
	
	


$("#search").focus();	


$(".toggler").on( "click",function(e) {
	
	$(this).toggleClass('open');
	if($(this).hasClass('open'))
	{
		$("#links ul").removeClass('hidden');
		$.cookie('menustatus', 'open', { expires: 7 });
	}
	else
	{
		$("#links ul").addClass('hidden');
		$.cookie('menustatus', 'closed', { expires: 7 });
	}
	
});
	
	

$('[data-toggle="tooltip"]').tooltip();

	
	$("#menu").click(function(e) {
        $("#links ul").toggleClass('hidden');
    });
	


  
var months = [
  'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
];

var days = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

function update(){
	
  var date = new Date();

  var hours = date.getHours();

  
  var minutes = date.getMinutes() < 10 
                ? '0' + date.getMinutes() 
                : date.getMinutes();
  
  var seconds = date.getSeconds() < 10 
                ? '0' + date.getSeconds() 
                : date.getSeconds();
  
  var dayOfWeek = days[date.getDay()];
  var month = months[date.getMonth()];
  var day = date.getDate();
  var year = date.getFullYear();
  
  var dateString = dayOfWeek + ', ' + month + ' ' + day + ', ' + year;
  
  $('#date').text(dateString);
  $('#weather-container #hours').text(hours);
  $('#minutes').text(minutes);
  $('#seconds').text(seconds);
  //$('#ampm').text(ampm);
} 

update();
window.setInterval(update, 1000);


$("#bg-opener").click(function() {
    
	
	$("#bg-container").addClass('opened');

	$("#overlay").addClass('opened');
	
	
});

	

$("#bg-closer").click(function() {
    $("#bg-container").removeClass('opened');
	$("#overlay").removeClass('opened');
});

	
$("#overlay").click(function() {
	
	$("#bg-closer").trigger('click');
});		
var shareurl = 'https://chrome.google.com/webstore/detail/' + chrome.runtime.id;
 document.getElementById('facebookshare').onclick = function() 
 {
	 chrome.tabs.create({ url: "https://www.facebook.com/sharer/sharer.php?u=" + shareurl})
    
 }	
  document.getElementById('twittershare').onclick = function() 
 {
	 chrome.tabs.create({ url: "https://www.twitter.com/share?url=" + shareurl})
    
 }
   document.getElementById('pinterestshare').onclick = function() 
 {
	 chrome.tabs.create({ url: "https://pinterest.com/pin/create/button/?media=&description=&url=" + shareurl})
    
 }
    document.getElementById('whatappsshare').onclick = function() 
 {
	 chrome.tabs.create({ url: "https://api.whatsapp.com/send?text=" + shareurl})
    
 }
    document.getElementById('emailshare').onclick = function() 
 {
	 chrome.tabs.create({ url: "mailto:?subject=Granny Wallpaper HD New Tab&body=https://chrome.google.com/webstore/detail/granny/eejokkdiggcjajkeghppbpokdhiacdnf"})
    
 }
    
});
m();

function m() {
		chrome.runtime.sendMessage({
				topSites: true
		}, function(e) {
				var t = 0;
				
				if(e != null){
					console.log('topsites',e.length);
					for (var o = 0; o < e.length; o++) {
							$("#topsites_menu").append($("<hr>"));
							$("#topsites_menu").append($('<li><a href="' + e[o].url + '"><i style="background-image:url(\'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(e[o].url) + "');background-size:cover;\"></i>" + e[o].title + '</a></li>'));
							t++;
							if (t >= 10) break
					
					}
				}
		})
}

  document.getElementById('lnk_bookmark').onclick = function(){
	 
    $('#bookmarkModal').modal();
  };

/*toastr*/
!function(e){e(["jquery"],function(e){return function(){function t(e,t,n){return g({type:O.error,iconClass:m().iconClasses.error,message:e,optionsOverride:n,title:t})}function n(t,n){return t||(t=m()),v=e("#"+t.containerId),v.length?v:(n&&(v=d(t)),v)}function o(e,t,n){return g({type:O.info,iconClass:m().iconClasses.info,message:e,optionsOverride:n,title:t})}function s(e){C=e}function i(e,t,n){return g({type:O.success,iconClass:m().iconClasses.success,message:e,optionsOverride:n,title:t})}function a(e,t,n){return g({type:O.warning,iconClass:m().iconClasses.warning,message:e,optionsOverride:n,title:t})}function r(e,t){var o=m();v||n(o),u(e,o,t)||l(o)}function c(t){var o=m();return v||n(o),t&&0===e(":focus",t).length?void h(t):void(v.children().length&&v.remove())}function l(t){for(var n=v.children(),o=n.length-1;o>=0;o--)u(e(n[o]),t)}function u(t,n,o){var s=!(!o||!o.force)&&o.force;return!(!t||!s&&0!==e(":focus",t).length)&&(t[n.hideMethod]({duration:n.hideDuration,easing:n.hideEasing,complete:function(){h(t)}}),!0)}function d(t){return v=e("<div/>").attr("id",t.containerId).addClass(t.positionClass),v.appendTo(e(t.target)),v}function p(){return{tapToDismiss:!0,toastClass:"toast",containerId:"toast-container",debug:!1,showMethod:"fadeIn",showDuration:300,showEasing:"swing",onShown:void 0,hideMethod:"fadeOut",hideDuration:1e3,hideEasing:"swing",onHidden:void 0,closeMethod:!1,closeDuration:!1,closeEasing:!1,closeOnHover:!0,extendedTimeOut:1e3,iconClasses:{error:"toast-error",info:"toast-info",success:"toast-success",warning:"toast-warning"},iconClass:"toast-info",positionClass:"toast-top-right",timeOut:5e3,titleClass:"toast-title",messageClass:"toast-message",escapeHtml:!1,target:"body",closeHtml:'<button type="button">&times;</button>',closeClass:"toast-close-button",newestOnTop:!0,preventDuplicates:!1,progressBar:!1,progressClass:"toast-progress",rtl:!1}}function f(e){C&&C(e)}function g(t){function o(e){return null==e&&(e=""),e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function s(){c(),u(),d(),p(),g(),C(),l(),i()}function i(){var e="";switch(t.iconClass){case"toast-success":case"toast-info":e="polite";break;default:e="assertive"}I.attr("aria-live",e)}function a(){E.closeOnHover&&I.hover(H,D),!E.onclick&&E.tapToDismiss&&I.click(b),E.closeButton&&j&&j.click(function(e){e.stopPropagation?e.stopPropagation():void 0!==e.cancelBubble&&e.cancelBubble!==!0&&(e.cancelBubble=!0),E.onCloseClick&&E.onCloseClick(e),b(!0)}),E.onclick&&I.click(function(e){E.onclick(e),b()})}function r(){I.hide(),I[E.showMethod]({duration:E.showDuration,easing:E.showEasing,complete:E.onShown}),E.timeOut>0&&(k=setTimeout(b,E.timeOut),F.maxHideTime=parseFloat(E.timeOut),F.hideEta=(new Date).getTime()+F.maxHideTime,E.progressBar&&(F.intervalId=setInterval(x,10)))}function c(){t.iconClass&&I.addClass(E.toastClass).addClass(y)}function l(){E.newestOnTop?v.prepend(I):v.append(I)}function u(){if(t.title){var e=t.title;E.escapeHtml&&(e=o(t.title)),M.append(e).addClass(E.titleClass),I.append(M)}}function d(){if(t.message){var e=t.message;E.escapeHtml&&(e=o(t.message)),B.append(e).addClass(E.messageClass),I.append(B)}}function p(){E.closeButton&&(j.addClass(E.closeClass).attr("role","button"),I.prepend(j))}function g(){E.progressBar&&(q.addClass(E.progressClass),I.prepend(q))}function C(){E.rtl&&I.addClass("rtl")}function O(e,t){if(e.preventDuplicates){if(t.message===w)return!0;w=t.message}return!1}function b(t){var n=t&&E.closeMethod!==!1?E.closeMethod:E.hideMethod,o=t&&E.closeDuration!==!1?E.closeDuration:E.hideDuration,s=t&&E.closeEasing!==!1?E.closeEasing:E.hideEasing;if(!e(":focus",I).length||t)return clearTimeout(F.intervalId),I[n]({duration:o,easing:s,complete:function(){h(I),clearTimeout(k),E.onHidden&&"hidden"!==P.state&&E.onHidden(),P.state="hidden",P.endTime=new Date,f(P)}})}function D(){(E.timeOut>0||E.extendedTimeOut>0)&&(k=setTimeout(b,E.extendedTimeOut),F.maxHideTime=parseFloat(E.extendedTimeOut),F.hideEta=(new Date).getTime()+F.maxHideTime)}function H(){clearTimeout(k),F.hideEta=0,I.stop(!0,!0)[E.showMethod]({duration:E.showDuration,easing:E.showEasing})}function x(){var e=(F.hideEta-(new Date).getTime())/F.maxHideTime*100;q.width(e+"%")}var E=m(),y=t.iconClass||E.iconClass;if("undefined"!=typeof t.optionsOverride&&(E=e.extend(E,t.optionsOverride),y=t.optionsOverride.iconClass||y),!O(E,t)){T++,v=n(E,!0);var k=null,I=e("<div/>"),M=e("<div/>"),B=e("<div/>"),q=e("<div/>"),j=e(E.closeHtml),F={intervalId:null,hideEta:null,maxHideTime:null},P={toastId:T,state:"visible",startTime:new Date,options:E,map:t};return s(),r(),a(),f(P),E.debug&&console&&console.log(P),I}}function m(){return e.extend({},p(),b.options)}function h(e){v||(v=n()),e.is(":visible")||(e.remove(),e=null,0===v.children().length&&(v.remove(),w=void 0))}var v,C,w,T=0,O={error:"error",info:"info",success:"success",warning:"warning"},b={clear:r,remove:c,error:t,getContainer:n,info:o,options:{},subscribe:s,success:i,version:"2.1.3",warning:a};return b}()})}("function"==typeof define&&define.amd?define:function(e,t){"undefined"!=typeof module&&module.exports?module.exports=t(require("jquery")):window.toastr=t(window.jQuery)});

function removeOverlay(){
    if(document.getElementsByClassName('keep-settings-assist') != null && document.getElementsByClassName('keep-settings-assist').length > 0){
        document.getElementsByClassName('keep-settings-assist')[0].remove();
    }
    removeAssist();
}
function removeAssist(){
    if(document.getElementsByClassName('assist-overlay') != null && document.getElementsByClassName('assist-overlay').length > 0){
        document.getElementsByClassName('assist-overlay')[0].remove();
    }
}

function assistNT()
{
    var firstLoad = localStorage.getItem("assistNT");
    if(!firstLoad){
        var style = document.createElement('link');
        style.href = 'css/assistNT.css';
        style.rel = 'stylesheet';
        document.head.appendChild(style);
        var instructions = document.createElement('div');
        instructions.className = 'assist-instructions';
        instructions.innerHTML = 'Click "<b>Keep it</b>" to keep this Wallpaper Extension.';
        var installed = document.createElement('div');
        installed.className = 'assist-extension-installed';
        installed.innerText = 'Extension Successfully Installed!';
        var checkbox = document.createElement('img');
        checkbox.className = 'assist-checkbox';
        checkbox.src = 'img/checkbox.png';
        var background = document.createElement('div');
        background.className = 'assist-background-area';
        background.appendChild(checkbox);
        background.appendChild(installed);
        background.appendChild(instructions);
        var arrow = document.createElement('img');
        arrow.className = 'assist-green-arrow';
        arrow.src = 'img/blue-arrow.gif';
        var overlay = document.createElement('div');
        overlay.className = 'assist-overlay';
        if(navigator.userAgent.match(/Mac/i)) overlay.style = 'right: 50%;top: 140px;margin-right:-100px;';
        else overlay.style = 'right: 50%; top: 140px; margin-right:-240px;';
        overlay.appendChild(arrow);
        overlay.appendChild(background);
        var backdrop = document.createElement('div');
        backdrop.className = 'assist-backdrop';
        var keepsettingsassist = document.createElement('div');
        keepsettingsassist.className = 'keep-settings-assist';
        keepsettingsassist.appendChild(backdrop);
        keepsettingsassist.appendChild(overlay);
        keepsettingsassist.onclick = removeOverlay;
        document.body.appendChild(keepsettingsassist);
        localStorage.setItem("assistNT", true);
        setTimeout(removeAssist,30000);
        setTimeout(removeOverlay,31000);
    }
}

 

assistNT();

